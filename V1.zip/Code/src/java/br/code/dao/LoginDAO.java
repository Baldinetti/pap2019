/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.code.dao;

import br.code.model.Cliente;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author lucas
 */
public class LoginDAO {
    
    EntityManagerFactory factory ;
    EntityManager entityManager;

    private EntityManager getEntityManager() {
        try {
            factory = Persistence.createEntityManagerFactory("WorknowPU");
            entityManager = factory.createEntityManager();
        } catch (Exception e) {
            System.out.println("Erro na Conexão");
        }
        return entityManager;
    }
    
    
    public boolean controleLogin(String email, String senha) {
        try {

            factory = Persistence.createEntityManagerFactory("WorknowPU");
            entityManager = factory.createEntityManager();
            
          
          
            Cliente c = entityManager.createNamedQuery("Cliente.consultarUsuarios", Cliente.class).setParameter("email", email).setParameter("senha", senha).getSingleResult();
            
            
            if (c!= null) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}
