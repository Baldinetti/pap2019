package br.code.dao;


import br.code.model.Cliente;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CadastroDAO {

    EntityManagerFactory factory ;
    EntityManager entityManager;

    private EntityManager getEntityManager() {
        factory = Persistence.createEntityManagerFactory("CodePU2");
        entityManager = factory.createEntityManager();

        return entityManager;
    }

    public Cliente salvar(Cliente cadastrar) {
        EntityManager entityManager = getEntityManager();
        try {
            entityManager.getTransaction().begin();
            if (cadastrar.getIdCliente() == null) {
                entityManager.persist(cadastrar);
            } else {
                entityManager.merge(cadastrar);
            }
            entityManager.getTransaction().commit();
        } finally {
            entityManager.close();
        }
        return cadastrar;
    }

    public Cliente consultarPorId(Long id) {
        return entityManager.find(Cliente.class, id);
    }
}
