/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.code.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 *
 * @author lucas
 */
@Entity
@Table(name = "TELEFONE")
@SequenceGenerator(name = "TEL_SEQ", sequenceName = "TEL_SEQ", initialValue = 1,
        allocationSize = 1)
public class Telefone implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "TEL_SEQ")
    @Column(name = "ID_TELEFONE")
    private Long idTelefone;
  
    @Column(name = "NUMERO")
    private String numero;
    
    @JoinColumn(name = "ID_TELEFONE", referencedColumnName = "ID_CLIENTE", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Cliente cliente;
    
    @JoinColumn(name = "IDCLIENTE", referencedColumnName = "ID_CLIENTE")
    @ManyToOne
    private Cliente idcliente;

    public Telefone() {
    }

    public Telefone(Long idTelefone) {
        this.idTelefone = idTelefone;
    }

    public Long getIdTelefone() {
        return idTelefone;
    }

    public void setIdTelefone(Long idTelefone) {
        this.idTelefone = idTelefone;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Cliente getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(Cliente idcliente) {
        this.idcliente = idcliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTelefone != null ? idTelefone.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Telefone)) {
            return false;
        }
        Telefone other = (Telefone) object;
        if ((this.idTelefone == null && other.idTelefone != null) || (this.idTelefone != null && !this.idTelefone.equals(other.idTelefone))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.code.model.Telefone[ idTelefone=" + idTelefone + " ]";
    }
    
}
