/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.code.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 *
 * @author Faculdade
 */
@Entity
@Table(name = "CATEGORIAS")
@SequenceGenerator(name = "CAT_SEQ", sequenceName = "CAT_SEQ", initialValue = 1,
        allocationSize = 1)
public class Categorias implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "CAT_SEQ")
    @Column(name = "ID_CATEGORIA")
    private Long idCategorias;
    
    @Column(name="CATEGORIA")
    private String categorias;

    public String getCategorias() {
        return categorias;
    }

    public void setCategorias(String categorias) {
        this.categorias = categorias;
    }
    
    

    public Long getIdCategorias() {
        return idCategorias;
    }

    public void setIdCategorias(Long idCategorias) {
        this.idCategorias = idCategorias;
    }
    
    
    
    
}
