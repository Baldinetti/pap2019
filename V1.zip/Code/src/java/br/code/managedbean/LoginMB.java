/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.code.managedbean;

import br.code.dao.LoginDAO;
import br.code.model.Cliente;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.primefaces.context.RequestContext;

/**
 *
 * @author lucas
 */
@ManagedBean
@SessionScoped
public class LoginMB {
    
    Cliente cliente = new Cliente();
    LoginDAO dao = new LoginDAO();

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    
    public String login() {
        if (dao.controleLogin(cliente.getEmail(), cliente.getSenha())) {
            return "cadastro.xhtml?faces-redirect=true";
        }

        RequestContext.getCurrentInstance().update("growl");
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Email ou senha invalidos!!!"));
        return "";
    }
    
    public String telaCadastro() {
        return "../cadastro.xhtml?faces-redirect=true";
    }
    
}
