
package br.code.managedbean;

import br.code.dao.CadastroDAO;
import br.code.model.Categorias;
import br.code.model.Cliente;
import br.code.model.ClienteJSF;
import br.code.model.Endereco;
import br.code.model.Telefone;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class CadastroMB {
    Cliente c = new Cliente();
    ClienteJSF jsf = new ClienteJSF();

    public Cliente getC() {
        return c;
    }

    public void setC(Cliente c) {
        this.c = c;
    }

    public ClienteJSF getJsf() {
        return jsf;
    }

    public void setJsf(ClienteJSF jsf) {
        this.jsf = jsf;
    }
    
    public void cadastroJSF(){
        Endereco end = new Endereco();
        end.setLogradouro(jsf.getLogradouro());
        end.setComplemento(jsf.getComplemento());
        end.setBairro(jsf.getBairro());
        end.setCidade(jsf.getCidade());
        end.setEstado(jsf.getEstado());
        end.setCep(jsf.getEstado());
        
        Categorias cat = new Categorias();
        cat.setCategorias(jsf.getCategorias());
        
        Telefone tel = new Telefone();
        tel.setNumero(jsf.getNumero());
        
        List<Telefone> telefones = new ArrayList<Telefone>();
        telefones.add(tel);
        
        c.setEndereco(end);
        c.setTelefoneList(telefones);
        c.setCategorias(cat);
        c.setNome(jsf.getNome());
        c.setSenha(jsf.getSenha());
        c.setEmail(jsf.getEmail());
        c.setAnosExperiencia(jsf.getAnosExperiencia());
        c.setReferencias(jsf.getReferencias());
        
        CadastroDAO dao = new CadastroDAO();
        dao.salvar(this.c);
        this.jsf = new ClienteJSF();
    }
}
