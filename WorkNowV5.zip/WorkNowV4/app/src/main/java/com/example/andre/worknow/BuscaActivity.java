package com.example.andre.worknow;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.Spinner;


public class BuscaActivity extends AppCompatActivity {

    private String[] profissoesNome = new String[]{ "Selecione", "Eletricista" ,"Encanador", "Jardineiro", "Gesseiro", "Marceneiro", "Pedreiro" , "Pintor", "Telhadista" };
    private String[] regiaoNome = new String[]{ "Selecione", "São Paulo", "Santo Andre", "São Caetano", "São Bernardo", "Diadema","Maua"};

    private Spinner sp;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.busca);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,profissoesNome);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner sp = (Spinner) findViewById(R.id.spinner1);
        sp.setAdapter(adapter);


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,regiaoNome);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        Spinner sp1 = (Spinner) findViewById(R.id.spinner2);
        sp1.setAdapter(adapter1);


        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }


    public void buscarprofissional(View view) {

        startActivity(new Intent(this, ListaActivity.class));
        //chamar a tela de tarefas.


    }





}

