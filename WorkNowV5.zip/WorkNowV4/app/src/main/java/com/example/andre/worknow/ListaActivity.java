package com.example.andre.worknow;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;

import com.example.andre.worknow.R;

import java.util.ArrayList;
import java.util.List;


public class ListaActivity extends AppCompatActivity {

    ListView listViewCadastros;
    CadastroDB db = new CadastroDB(this);
    ArrayList<String> arrayList;
    ArrayAdapter <String> adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista);

        EditText nome = (EditText) findViewById(R.id.nome);
        EditText email = (EditText) findViewById(R.id.email);
        EditText senha = (EditText) findViewById(R.id.senha);
        EditText telefone = (EditText) findViewById(R.id.telefone);
        EditText logradouro = (EditText) findViewById(R.id.logradouro);
        EditText bairro = (EditText) findViewById(R.id.bairro);
        EditText cidade = (EditText) findViewById(R.id.cidade);
        EditText estado = (EditText) findViewById(R.id.estado);
        EditText profissao = (EditText) findViewById(R.id.profissao);
        EditText referencias = (EditText) findViewById(R.id.referencias);

        Button btnSalvar = (Button) findViewById(R.id.salvar);
        Button btnVoltar = (Button) findViewById(R.id.voltar);

       listViewCadastros = (ListView) findViewById(R.id.lista);



    }



    public  void listarCadastros(){
        List<Cadastro> cad = db.consultarCadastrados();

        arrayList = new ArrayList<String>();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayList);
        listViewCadastros.setAdapter(adapter);

        for( Cadastro c : cad){
            arrayList.add(c.getNome() + " - " + c.getProfissao());
            adapter.notifyDataSetChanged();
        }

    }
    public void detalhes(View view) {

        startActivity(new Intent(this, FichaActivity.class));
        //chamar a tela de tarefas.


    }



}