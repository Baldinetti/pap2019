package com.example.andre.worknow;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.Spinner;

import java.util.ArrayList;


public class BuscaActivity extends Activity {

    String nome;
    Spinner spinner;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.busca);

        BuscaDB datahelper = new BuscaDB(this);
        datahelper.insertProvince("");
        datahelper.insertProvince("Eletricista" );
        datahelper.insertProvince("Encanador");
        datahelper.insertProvince("Jardineiro");
        datahelper.insertProvince("Marceneiro");
        datahelper.insertProvince("Pedreiro");
        datahelper.insertProvince("Pintor");
        datahelper.insertProvince("Telhadista");

        spinner=(Spinner)findViewById(R.id.spinner1);
        ArrayList<String> list=datahelper.getAllProvinces();
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, R.layout.spinner, R.id.text, list);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                nome = parent.getItemAtPosition(position).toString();
                //Toast.makeText(BuscaActivity.this, "Nome Selecionado: " + nome, Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    public void buscarprofissional(View view){

        Bundle bundle = new Bundle();
        bundle.putString("selecionado", this.nome);

        Intent intent = new Intent(getBaseContext(), BuscaActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);

    }

}

