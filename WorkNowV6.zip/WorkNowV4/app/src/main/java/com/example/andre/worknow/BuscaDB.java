package com.example.andre.worknow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class BuscaDB extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "prodb";
    public static final String TABLE_PRO = "tblprovinces";
    public static final int DATABASE_VERSION = 1;
    public static final String CREATE_RPO = "CREATE TABLE IF NOT EXISTS " + TABLE_PRO + "(id INTEGER PRIMARY KEY AUTOINCREMENT, pname TEXT NULL UNIQUE)";

    public static final String DELETE_PRO = "DROP TABLE IF EXISTS " + TABLE_PRO;

    public BuscaDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_RPO);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        db.execSQL(DELETE_PRO);

        onCreate(db);

    }

    public void insertProvince(String pname) {

        // Open the database for writing
        SQLiteDatabase db = this.getWritableDatabase();
        // Start the transaction.
        db.beginTransaction();
        ContentValues values;


        try {
            values = new ContentValues();
            values.put("pname", pname);
            // Insert Row
            db.insert(TABLE_PRO, null, values);
            // Insert into database successfully.
            db.setTransactionSuccessful();


        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            // End the transaction.
            db.close();
            // Close database
        }
    }


    public ArrayList<String> getAllProvinces() {

        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();


        try {

            String selectQuery = "SELECT * FROM " + TABLE_PRO;
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String pname = cursor.getString(cursor.getColumnIndex("pname"));
                    list.add(pname);

                }


            }
            db.setTransactionSuccessful();

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            db.endTransaction();
            db.close();

        }
        return list;


    }





}



