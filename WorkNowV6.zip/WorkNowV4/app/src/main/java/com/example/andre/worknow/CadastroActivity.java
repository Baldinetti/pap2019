package com.example.andre.worknow;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);
    }

    public void addClient(View view) {
        Intent intent = new Intent();
        intent.putExtra("nome", ((EditText) findViewById(R.id.nome)).getText().toString());
        intent.putExtra("email", ((EditText) findViewById(R.id.email)).getText().toString());
        intent.putExtra("senha", ((EditText) findViewById(R.id.senha)).getText().toString());
        intent.putExtra("telefone", ((EditText) findViewById(R.id.telefone)).getText().toString());
        intent.putExtra("logradouro", ((EditText) findViewById(R.id.logradouro)).getText().toString());
        intent.putExtra("bairro", ((EditText) findViewById(R.id.bairro)).getText().toString());
        intent.putExtra("cidade", ((EditText) findViewById(R.id.cidade)).getText().toString());
        intent.putExtra("estado", ((EditText) findViewById(R.id.estado)).getText().toString());
        intent.putExtra("profissão", ((EditText) findViewById(R.id.profissao)).getText().toString());
        intent.putExtra("referencias", ((EditText) findViewById(R.id.referencias)).getText().toString());


        setResult(Activity.RESULT_OK, intent);
        finish();
    }


}