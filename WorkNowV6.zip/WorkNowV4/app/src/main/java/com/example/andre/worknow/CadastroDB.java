package com.example.andre.worknow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class CadastroDB extends SQLiteOpenHelper {

    private static final int VERSAO_BANCO = 1;
    private static final String BANCO_CLIENTE = "Bd_cadastros";

    public CadastroDB(Context context){
        super(context, BANCO_CLIENTE, null, VERSAO_BANCO);

    }


    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE CADASTRO(_id INTEGER PRIMARY KEY "+ "AUTOINCREMENT, nome TEXT, email TEXT, senha TEXT, telefone TEXT," +
                "logradouro TEXT, bairro TEXT, cidade TEXT, estado TEXT, profissao TEXT, referencias TEXT);");

    }

    public Cadastro salvaCadastro( Cadastro cadastro){
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put("nome", cadastro.getNome());
            values.put("email", cadastro.getEmail());
            values.put("senha", cadastro.getSenha());
            values.put("telefone", cadastro.getTelefone());
            values.put("logradouro", cadastro.getLogradouro());
            values.put("bairro", cadastro.getBairro());
            values.put("cidade", cadastro.getCidade());
            values.put("estado", cadastro.getEstado());
            values.put("profissao", cadastro.getProfissao());
            values.put("referencias", cadastro.getReferencias());

            if (cadastro.get_id() == null){
                long id = db.insert("Cadastro", null, values);
                cadastro.set_id(id);
            }
        }finally {
            db.close();
        }
        return cadastro;
    }


    public List<Cadastro> consultarCadastrados(){
        List<Cadastro> lista = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery("SELECT _id, nome, email, telefone, logradouro, bairro, profissao, referencias" +
                    "FROM Cadastro", null);
            cursor.moveToFirst();

            for (int i =0; i < cursor.getCount(); i++){
                Cadastro cadastro = new Cadastro();
                cadastro.set_id(cursor.getLong(0));
                cadastro.setNome(cursor.getString(1));
                cadastro.setEmail(cursor.getString(2));
                cadastro.setLogradouro(cursor.getString(3));
                cadastro.setBairro(cursor.getString(4));
                cadastro.setProfissao(cursor.getString(5));
                cadastro.setReferencias(cursor.getString(6));
                lista.add(cadastro);
                cursor.moveToNext();
            }
            cursor.close();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            db.close();
        }
        return  lista;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}
